// Copyright MyScript. All rights reserved.

package com.myscript.iink.uireferenceimplementation;

public interface ISizeListener {
    void sizeChanged(int newWidth, int newHeight);
}
