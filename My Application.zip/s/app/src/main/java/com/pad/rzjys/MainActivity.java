package com.pad.rzjys;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.myscript.iink.PointerEvent;
import com.pad.rzjys.IdentifyUtils.IdentifyUtil;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        IdentifyUtil.SingletonIdentifyUtil(); //识别初始化
        //识别结果
        IdentifyUtil.setonIdentifyListener(new IdentifyUtil.onIdentifyListener() {
            @Override
            public void onIdentifyListener(final String s) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Log.e("TAG", "run: "+"识别结果" + s );
                    }
                });
            }

            @Override
            public void onIdentifyErrorListener() {
                Log.e("识别", "onIdentifyErrorListener: ");
            }
        });

    }





    /**
     * 识别
     */
    private void initIdentify() {

        // TODO: 2020/10/28  提示：！！！！！

        //src/main/java/com/pad/rzjy/IdentifyUtils/certificate/MyCertificates.java
        // MyCertificate  -- 需要用该应用包名 重新申请证书后之后覆盖   （我方提供）

        //识别的点码  第一个点必须为  down    最后一点  为  up   每一笔 的格式需 为：   down    move   move  move 。。。。 up

        //识别的点码 必须 为    >=  3

        //识别 一个识别可能返回多次结果 识别中切勿重复识别 以免造成识别结果遗失


        // TODO: 2020/10/28  该示例 仅供参考 具体转换 需按实际情况 自行操作
        //例如
//        String ss = "[ \"x\":\"1\", \"y\":\"1\", \"type\":\"0\"]";

//        //转换
//        ArrayList<PointerEvent> pointerEvents = (ArrayList<PointerEvent>) Dot2VO.jsonToList(ss);



//        IdentifyUtil.SingletonIdentifyUtil(); //识别初始化

        //识别结果
        IdentifyUtil.setonIdentifyListener(new IdentifyUtil.onIdentifyListener() {
            @Override
            public void onIdentifyListener(final String s) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Log.e("TAG", "run: "+"识别结果" + s );
                    }
                });
            }

            @Override
            public void onIdentifyErrorListener() {
                Log.e("识别", "onIdentifyErrorListener: ");
            }
        });


        // 识别  假数据
        ArrayList<PointerEvent> events = new ArrayList<PointerEvent>();

        // Stroke 1
        events.add(new PointerEvent().down(484.f, 424.f));
        events.add(new PointerEvent().move(484.f, 425.f));
        events.add(new PointerEvent().move(484.f, 428.f));
        events.add(new PointerEvent().move(484.f, 433.f));
        events.add(new PointerEvent().move(484.f, 452.f));
        events.add(new PointerEvent().move(484.f, 458.f));
        events.add(new PointerEvent().move(484.f, 463.f));
        events.add(new PointerEvent().move(483.f, 467.f));
        events.add(new PointerEvent().move(483.f, 474.f));
        events.add(new PointerEvent().move(483.f, 483.f));
        events.add(new PointerEvent().up(483.f, 484.f));


        // Stroke 2
        events.add(new PointerEvent().down(450.f, 426.f));
        events.add(new PointerEvent().move(454.f, 426.f));
        events.add(new PointerEvent().move(452.f, 426.f));
        events.add(new PointerEvent().move(458.f, 426.f));
        events.add(new PointerEvent().move(466.f, 426.f));
        events.add(new PointerEvent().move(484.f, 426.f));
        events.add(new PointerEvent().move(490.f, 428.f));
        events.add(new PointerEvent().move(496.f, 428.f));
        events.add(new PointerEvent().move(500.f, 428.f));
        events.add(new PointerEvent().move(507.f, 428.f));
        events.add(new PointerEvent().move(508.f, 428.f));
        events.add(new PointerEvent().up(509.f, 428.f));


        //识别  true  中文  false 英文
//        IdentifyUtil.toIdentify(true, events);

        //识别
//        IdentifyUtil.toIdentify( events);

    }

    public void sss(View view) {

        // 识别  假数据
        ArrayList<PointerEvent> events = new ArrayList<PointerEvent>();

        // Stroke 1
        events.add(new PointerEvent().down(484.f, 424.f));
        events.add(new PointerEvent().move(484.f, 425.f));
        events.add(new PointerEvent().move(484.f, 428.f));
        events.add(new PointerEvent().move(484.f, 433.f));
        events.add(new PointerEvent().move(484.f, 452.f));
        events.add(new PointerEvent().move(484.f, 458.f));
        events.add(new PointerEvent().move(484.f, 463.f));
        events.add(new PointerEvent().move(483.f, 467.f));
        events.add(new PointerEvent().move(483.f, 474.f));
        events.add(new PointerEvent().move(483.f, 483.f));
        events.add(new PointerEvent().up(483.f, 484.f));


        // Stroke 2
        events.add(new PointerEvent().down(450.f, 426.f));
        events.add(new PointerEvent().move(454.f, 426.f));
        events.add(new PointerEvent().move(452.f, 426.f));
        events.add(new PointerEvent().move(458.f, 426.f));
        events.add(new PointerEvent().move(466.f, 426.f));
        events.add(new PointerEvent().move(484.f, 426.f));
        events.add(new PointerEvent().move(490.f, 428.f));
        events.add(new PointerEvent().move(496.f, 428.f));
        events.add(new PointerEvent().move(500.f, 428.f));
        events.add(new PointerEvent().move(507.f, 428.f));
        events.add(new PointerEvent().move(508.f, 428.f));
        events.add(new PointerEvent().up(509.f, 428.f));



        //识别
        IdentifyUtil.toIdentify( events);

    }
}